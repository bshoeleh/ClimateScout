# CRTKL Climate Scout

Built for the CRTKL Performance Driven Design (PDD) Team
- Pablo La Roche <pablo.laroche@arcadis.com>
- Joey-Michelle Hutchison <joeymichelle.hutchison@arcadis.com>

## Authors
- Matthew Doll <matthew.doll@arcadis.com>

## Installation

1. Install Wordpress 6.x
2. Install SQLite DB Plugin
3. Copy over theme files from github
4. Set wordpress to use climatescout theme  
5. Setup Mapbox account
6. Set Mapbox AccessToken in
  - wp-content/themes/crtkl-climate/theme/js/carbon_map.js
  - wp-content/themes/crtkl-climate/theme/js/climate_map.js

## URL History
- apr 2021 www.callisonrtkl.com/climate-scout 
- jan 2024 climatescout.crtkl.com 
- mar 2024 climatescout.arcadis.com 
